//
//  SNHTimerProxy.h
//  DataBaseDemo
//
//  Created by majian on 2016/11/16.
//  Copyright © 2016年 majian. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SNHTimerProxy : NSObject

@property (nonatomic,weak) id timerTarget;

@end
